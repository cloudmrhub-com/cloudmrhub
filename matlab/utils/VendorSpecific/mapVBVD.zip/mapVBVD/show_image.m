%!ln -s ~/Dropbox/For_Eros/SNR_rawdata_examples/Hip_Body18_Skyra_SNRRawData/meas_MID273_SNR_Tra2_BW300_FID13631.dat `pwd`/tra2.dat
C=mapVBVD('tra2.dat');
A=C.image();
for a=1:size(A,2); imshow(abs(fftshift(ifft2(squeeze(A(:,a,:))))),[]);pause;end